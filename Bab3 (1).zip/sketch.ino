// =============================================
// Praktikum 1: LED Blink - LED Built-in ESP32
// GPIO 2 = LED Built-in pada ESP32 DevKit V1
// =============================================

#define LED_PIN 2      // LED built-in pada GPIO 2

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);  // set GPIO 2 sebagai OUTPUT
  Serial.println("Program LED Blink dimulai!");
}

void loop() {
  digitalWrite(LED_PIN, HIGH);   // Nyalakan LED
  Serial.println("LED: ON");
  delay(1000);                   // Tunggu 1 detik

  digitalWrite(LED_PIN, LOW);    // Matikan LED
  Serial.println("LED: OFF");
  delay(1000);                   // Tunggu 1 detik
}

