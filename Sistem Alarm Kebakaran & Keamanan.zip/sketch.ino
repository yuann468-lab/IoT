#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>

// Definisi pin dan konfigurasi
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

#define DHTPIN 4       // Pin data DHT22 terhubung ke GPIO 4
#define DHTTYPE DHT22  // Jenis sensor DHT
DHT dht(DHTPIN, DHTTYPE);

#define PIR_PIN 13     // Pin OUT Sensor PIR terhubung ke GPIO 13
#define BUZZER_PIN 23  // Pin Positif Buzzer terhubung ke GPIO 23

// Batas ambang suhu untuk peringatan kebakaran (misal di atas 38 derajat Celcius)
const float TEMP_THRESHOLD = 38.0; 

void setup() {
  Serial.begin(115200);

  // Inisialisasi pin
  pinMode(PIR_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  // Inisialisasi sensor DHT
  dht.begin();

  // Inisialisasi layar OLED (I2C address 0x3C)
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("Alokasi SSD1306 gagal"));
    for(;;);
  }
  
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println(F("Sistem Keamanan"));
  display.println(F("Memulai sistem..."));
  display.display();
  delay(2000);
}

void loop() {
  // Membaca suhu dan kelembapan dari DHT22
  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature(); // Celsius

  // Membaca status sensor gerakan PIR
  int motionState = digitalRead(PIR_PIN);

  // Cek apakah pembacaan dari sensor DHT gagal
  if (isnan(humidity) || isnan(temperature)) {
    Serial.println(F("Gagal membaca dari sensor DHT!"));
    return;
  }

  // Logika Deteksi Bahaya (Kebakaran atau Gerakan Mencurigakan)
  bool fireAlert = (temperature >= TEMP_THRESHOLD);
  bool motionAlert = (motionState == HIGH);

  if (fireAlert || motionAlert) {
    digitalWrite(BUZZER_PIN, HIGH); // Nyalakan Buzzer (Alarm berbunyi)
  } else {
    digitalWrite(BUZZER_PIN, LOW);  // Matikan Buzzer
  }

  // Tampilkan data ke Layar OLED
  display.clearDisplay();
  display.setCursor(0, 0);
  display.setTextSize(1);
  display.println(F("--- SISTEM ALARM ---"));
  
  // Tampilkan Suhu
  display.setCursor(0, 16);
  display.print(F("Suhu: "));
  display.print(temperature);
  display.println(F(" C"));

  // Tampilkan Kelembapan
  display.setCursor(0, 28);
  display.print(F("Hum : "));
  display.print(humidity);
  display.println(F(" %"));

  // Tampilkan Status Keamanan / Gerakan
  display.setCursor(0, 40);
  display.print(F("Gerak: "));
  if (motionAlert) {
    display.println(F("TERDETEKSI!"));
  } else {
    display.println(F("Aman"));
  }

  // Tampilkan Status Peringatan Kebakaran di Baris Bawah
  display.setCursor(0, 52);
  if (fireAlert) {
    display.println(F("BAHAYA: KEBAKARAN!"));
  } else {
    display.println(F("Status: NORMAL"));
  }

  display.display();

  // Jeda waktu pembacaan sensor (2 detik)
  delay(2000);
}
